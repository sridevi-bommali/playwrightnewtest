import * as dotenv from 'dotenv';
import * as path from 'path';

const envName = process.env.TEST_ENV || 'dev';
dotenv.config({ path: path.resolve(__dirname, 'env', `${envName}.env`) });

export const config = {
  baseURL: process.env.BASE_URL || '',
  username: process.env.USERNAME || '',
  password: process.env.PASSWORD || ''
};