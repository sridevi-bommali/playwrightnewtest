import * as xlsx from 'xlsx';
import path from 'path';

export function readExcel(filepath: string): Record<string, string>[] {
  const workbook = xlsx.readFile(filepath);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return xlsx.utils.sheet_to_json(sheet);
}

export function resolveData(input: string, row: Record<string, string>): string {
  return input.startsWith('$') ? row[input.slice(1)] || '' : input;
}