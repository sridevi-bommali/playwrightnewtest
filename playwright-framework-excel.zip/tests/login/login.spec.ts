import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { readExcel, resolveData } from '../../data/utils';
import { config } from '../../config/testConfig';

const dataRows = readExcel('./tests/login/loginData.xlsx');

dataRows.forEach((row) => {
  test(`@smoke Login Test - ${row.username}`, async ({ page }) => {
    const login = new LoginPage(page);
    await page.goto(config.baseURL);

    await login.login(
      resolveData(row.username, row),
      resolveData(row.password, row)
    );

    await expect(page.locator('h1')).toHaveText('Dashboard');
  });
});